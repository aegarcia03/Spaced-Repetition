from application import application
# This exposes `application` to WSGI (Gunicorn)
